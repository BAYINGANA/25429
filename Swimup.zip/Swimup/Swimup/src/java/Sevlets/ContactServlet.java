package Sevlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.logging.Level;
import java.util.logging.Logger;

import java.io.IOException;

@WebServlet("/ContactServlet")
public class ContactServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Initialize the logger using java.util.logging
    private static final Logger logger = Logger.getLogger(ContactServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String message = request.getParameter("message");

        // Log messages using java.util.logging syntax
        logger.log(Level.INFO, "Contact form submitted by: {0}", name);
        logger.log(Level.FINE, "Form data: name={0}, email={1}, message={2}", new Object[]{name, email, message});

        response.sendRedirect("http://localhost:3000/submit-form");
    }
}
