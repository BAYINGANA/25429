const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const cors = require('cors'); // Import CORS
const winston = require('winston');  // Import Winston

const app = express();
const port = 3000;

// Configure Winston for logging
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: 'C:\\Users\\DAV TECH Ltd\\Documents\\NetBeansProjects\\Swimup\\Swimup\\logs\\app.log' })
    ]
});

// PostgreSQL connection setup
const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "swimup",
    password: "shakilla@8Ishimwe",
    port: 5433,
});

// Use CORS middleware
app.use(cors());

// Parse JSON and URL-encoded data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Handle form submission
app.post('/submit-form', async (req, res) => {
    const { name, email, message } = req.body;

    try {
        const query = "INSERT INTO contacts (name, email, message) VALUES ($1, $2, $3)";
        await pool.query(query, [name, email, message]);

        logger.info('Contact form submitted', { name, email, message }); // Log submission

        res.send('Thank you for your message! We will get back to you soon.');
    } catch (err) {
        logger.error('Database connection problem', { error: err }); // Log errors
        res.status(500).send('Database connection problem');
    }
});

// Start server
app.listen(port, () => {
    logger.info(`Server running at http://localhost:${port}/`); // Log server start
    console.log(`Server running at http://localhost:${port}/`);
});
